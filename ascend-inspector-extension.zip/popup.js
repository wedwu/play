import { toggleInspector, applyConfig, getState } from './inject.js';

const DEFAULT_CFG = {
  ascendPrefixes: ['ts-', 'aa-', 'ascend-'],
  ascendTags: [],
  webAwesomePrefixes: ['wa-'],
  webAwesomeTags: [],
  colors: { ascend: '#6d5efc', webawesome: '#f5a524', unknown: '#94a3b8' },
};

const $ = (id) => document.getElementById(id);
const list = (s) => s.split(',').map((x) => x.trim()).filter(Boolean);
const setStatus = (msg) => ($('status').textContent = msg);

let tabId = null;
let isOn = false;

async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function readForm() {
  return {
    ascendPrefixes: list($('ascendPrefixes').value),
    ascendTags: list($('ascendTags').value),
    webAwesomePrefixes: ['wa-'],
    webAwesomeTags: [],
    colors: { ascend: $('cAscend').value, webawesome: $('cWa').value, unknown: '#94a3b8' },
  };
}

function fillForm(cfg) {
  $('ascendPrefixes').value = (cfg.ascendPrefixes ?? []).join(', ');
  $('ascendTags').value = (cfg.ascendTags ?? []).join(', ');
  $('cAscend').value = cfg.colors?.ascend ?? '#6d5efc';
  $('cWa').value = cfg.colors?.webawesome ?? '#f5a524';
}

function reflect() {
  $('toggle').classList.toggle('on', isOn);
  $('toggle').textContent = isOn ? 'On — turn off' : 'Turn on for this page';
}

async function save() {
  const cfg = readForm();
  await chrome.storage.sync.set({ cfg });
  if (isOn && tabId != null) {
    try { await applyConfig(tabId, cfg); } catch { /* page navigated away */ }
  }
}

async function init() {
  const tab = await activeTab();
  tabId = tab?.id ?? null;

  const { cfg } = await chrome.storage.sync.get('cfg');
  fillForm(cfg ?? DEFAULT_CFG);

  const restricted = !tab?.url || !/^https?:|^file:/.test(tab.url);
  if (restricted || tabId == null) {
    $('toggle').disabled = true;
    setStatus("Can't run on this page.");
    return;
  }

  try { isOn = await getState(tabId); } catch { isOn = false; }
  reflect();

  $('toggle').addEventListener('click', async () => {
    try {
      isOn = await toggleInspector(tabId);
      if (isOn) await applyConfig(tabId, readForm());
      reflect();
      setStatus('');
    } catch {
      setStatus("Can't run on this page.");
    }
  });

  for (const id of ['ascendPrefixes', 'ascendTags']) $(id).addEventListener('input', save);
  for (const id of ['cAscend', 'cWa']) $(id).addEventListener('change', save);
}

init();
