// Shared injection helpers. Everything runs in the page's MAIN world so the
// inspector can read the page's real custom-element registry (customElements.get),
// which is what powers the constructor-name classification signal.

async function ensureDefined(tabId) {
  // Idempotent: inspector.js guards its own customElements.define.
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ['inspector.js'],
    world: 'MAIN',
  });
}

export async function getState(tabId) {
  const [hit] = await chrome.scripting.executeScript({
    target: { tabId },
    world: 'MAIN',
    func: () => !!document.querySelector('ascend-inspector'),
  });
  return Boolean(hit?.result);
}

export async function toggleInspector(tabId) {
  await ensureDefined(tabId);
  const [hit] = await chrome.scripting.executeScript({
    target: { tabId },
    world: 'MAIN',
    func: () => {
      const cur = document.querySelector('ascend-inspector');
      if (cur) { cur.remove(); return false; }
      document.body.appendChild(document.createElement('ascend-inspector'));
      return true;
    },
  });
  return Boolean(hit?.result); // true = now on, false = now off
}

export async function applyConfig(tabId, cfg) {
  await chrome.scripting.executeScript({
    target: { tabId },
    world: 'MAIN',
    args: [cfg],
    func: (cfg) => {
      const el = document.querySelector('ascend-inspector');
      if (!el) return;
      if (cfg.ascendPrefixes) el.ascendPrefixes = cfg.ascendPrefixes;
      if (cfg.webAwesomePrefixes) el.webAwesomePrefixes = cfg.webAwesomePrefixes;
      if (cfg.ascendTags) el.ascendTags = cfg.ascendTags;
      if (cfg.webAwesomeTags) el.webAwesomeTags = cfg.webAwesomeTags;
      if (cfg.colors) el.colors = cfg.colors;
    },
  });
}
