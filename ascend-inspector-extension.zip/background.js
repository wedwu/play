import { toggleInspector, applyConfig } from './inject.js';

// Alt+Shift+A toggles without opening the popup. The command invocation grants
// activeTab, so no broad host permissions are needed.
chrome.commands.onCommand.addListener(async (command) => {
  if (command !== 'toggle-inspector') return;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return;
  try {
    const on = await toggleInspector(tab.id);
    if (on) {
      const { cfg } = await chrome.storage.sync.get('cfg');
      if (cfg) await applyConfig(tab.id, cfg);
    }
  } catch {
    // Restricted page (edge://, extension gallery, PDF viewer, etc.) — ignore.
  }
});
