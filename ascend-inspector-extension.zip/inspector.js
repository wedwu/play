/**
 * <ascend-inspector>
 * A live overlay that outlines every custom element on the page and classifies it as
 * Ascend Awesome, upstream Web Awesome, or unknown. Doubles as an adoption meter.
 *
 * Load it as an ES module, then use the element anywhere on the page:
 *   import './ascend-inspector.js';   // via a bundler, or a module script tag
 *   <ascend-inspector></ascend-inspector>
 *
 * Configure via properties (all optional):
 *   el.ascendTags       = ['ascend-card', 'wa-button'];   // force-classify by tag
 *   el.webAwesomeTags   = ['wa-select'];
 *   el.manifest         = <custom-elements.json object>;  // Ascend CEM -> its tags are Ascend
 *   el.colors           = { ascend, webawesome, unknown };
 *
 * Classification signals, highest confidence first:
 *   1. configured tag maps        2. marker attribute ([data-ascend]/[data-webawesome])
 *   3. constructor/prototype name 4. tag prefix (ascend-/asc- vs wa-)   5. unknown
 *
 * Keyboard: Alt+A toggles the overlay. Alt+Click a component to log it to the console.
 */

const LIBRARIES = ['ascend', 'webawesome', 'unknown'];

const DEFAULTS = {
  ascendTags: [],
  webAwesomeTags: [],
  ascendPrefixes: ['ascend-', 'asc-'],
  webAwesomePrefixes: ['wa-'],
  ascendAttribute: 'data-ascend',
  webAwesomeAttribute: 'data-webawesome',
  colors: { ascend: '#6d5efc', webawesome: '#f5a524', unknown: '#94a3b8' },
  labels: { ascend: 'Ascend Awesome', webawesome: 'Web Awesome', unknown: 'Unknown' },
};

function ctorChainNames(tag) {
  const C = customElements.get(tag);
  const names = [];
  let p = C;
  while (p && p !== HTMLElement && p !== Object && p.name) {
    names.push(p.name);
    p = Object.getPrototypeOf(p);
  }
  return names;
}

class AscendInspector extends HTMLElement {
  constructor() {
    super();
    this._cfg = structuredClone(DEFAULTS);
    this._cfg.ascendTags = new Set(DEFAULTS.ascendTags);
    this._cfg.webAwesomeTags = new Set(DEFAULTS.webAwesomeTags);

    this._enabled = true;
    this._pierce = false;
    this._showLabels = true;
    this._filters = { ascend: true, webawesome: true, unknown: true };

    this._targets = new Map(); // Element -> { box, label, cls }
    this._active = null;
    this._rafScan = 0;
    this._rafPos = 0;

    this._onScroll = () => this._scheduleReposition();
    this._onResize = () => this._scheduleReposition();
    this._onMouseMove = (e) => this._hover(e);
    this._onKey = (e) => {
      if (e.altKey && (e.key === 'a' || e.key === 'A')) {
        e.preventDefault();
        this._setEnabled(!this._enabled);
      }
    };
    this._onClick = (e) => {
      if (!this._enabled || !e.altKey) return;
      const el = this._targetFrom(e.composedPath?.()[0] ?? e.target);
      if (!el) return;
      e.preventDefault();
      const cls = this._targets.get(el)?.cls;
      // eslint-disable-next-line no-console
      console.log('%c[ascend-inspector]', `color:${this._cfg.colors[cls?.library] ?? '#888'}`, el, cls);
    };
  }

  // ---- public config setters ------------------------------------------------
  set ascendTags(v) { this._cfg.ascendTags = new Set(v ?? []); this._scan(); }
  set webAwesomeTags(v) { this._cfg.webAwesomeTags = new Set(v ?? []); this._scan(); }
  set ascendPrefixes(v) { this._cfg.ascendPrefixes = [...(v ?? [])]; this._scan(); }
  set webAwesomePrefixes(v) { this._cfg.webAwesomePrefixes = [...(v ?? [])]; this._scan(); }
  set colors(v) { Object.assign(this._cfg.colors, v ?? {}); this._applyTheme(); this._scan(); }
  set manifest(cem) {
    for (const t of AscendInspector.tagsFromManifest(cem)) this._cfg.ascendTags.add(t);
    this._scan();
  }

  static tagsFromManifest(cem) {
    const tags = [];
    for (const mod of cem?.modules ?? [])
      for (const d of mod.declarations ?? [])
        if (d.customElement && d.tagName) tags.push(d.tagName);
    return tags;
  }

  // ---- lifecycle ------------------------------------------------------------
  connectedCallback() {
    this._root = this.attachShadow({ mode: 'open' });
    this._root.innerHTML = TEMPLATE;
    this._overlay = this._root.getElementById('overlay');
    this._panel = this._root.getElementById('panel');
    this._tip = this._root.getElementById('tip');
    this._applyTheme();
    this._wirePanel();
    this._makeDraggable();

    this._mo = new MutationObserver(() => this._scheduleScan());
    this._mo.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: [this._cfg.ascendAttribute, this._cfg.webAwesomeAttribute] });

    addEventListener('scroll', this._onScroll, { capture: true, passive: true });
    addEventListener('resize', this._onResize, { passive: true });
    addEventListener('mousemove', this._onMouseMove, { passive: true });
    addEventListener('keydown', this._onKey);
    addEventListener('click', this._onClick, true);

    this._scan();
  }

  disconnectedCallback() {
    this._mo?.disconnect();
    removeEventListener('scroll', this._onScroll, { capture: true });
    removeEventListener('resize', this._onResize);
    removeEventListener('mousemove', this._onMouseMove);
    removeEventListener('keydown', this._onKey);
    removeEventListener('click', this._onClick, true);
    cancelAnimationFrame(this._rafScan);
    cancelAnimationFrame(this._rafPos);
  }

  // ---- classification -------------------------------------------------------
  classify(el) {
    const tag = el.localName;
    const c = this._cfg;
    const R = (library, confidence, reason) => ({ library, confidence, reason });

    if (c.ascendTags.has(tag)) return R('ascend', 'high', 'configured tag');
    if (c.webAwesomeTags.has(tag)) return R('webawesome', 'high', 'configured tag');
    if (c.ascendAttribute && el.hasAttribute(c.ascendAttribute)) return R('ascend', 'high', `[${c.ascendAttribute}]`);
    if (c.webAwesomeAttribute && el.hasAttribute(c.webAwesomeAttribute)) return R('webawesome', 'high', `[${c.webAwesomeAttribute}]`);

    const names = ctorChainNames(tag);
    const asc = names.find((n) => /ascend/i.test(n));
    if (asc) return R('ascend', 'high', `class ${asc}`);
    const wa = names.find((n) => /^Wa[A-Z]/.test(n) || /web\s*awesome/i.test(n));
    if (wa) return R('webawesome', 'high', `class ${wa}`);

    if (c.ascendPrefixes.some((p) => tag.startsWith(p))) return R('ascend', 'medium', `"${tag}" prefix`);
    if (c.webAwesomePrefixes.some((p) => tag.startsWith(p))) return R('webawesome', 'medium', `"${tag}" prefix`);

    return R('unknown', 'low', 'no signal matched');
  }

  // ---- scan / reposition ----------------------------------------------------
  _scheduleScan() { cancelAnimationFrame(this._rafScan); this._rafScan = requestAnimationFrame(() => this._scan()); }
  _scheduleReposition() { cancelAnimationFrame(this._rafPos); this._rafPos = requestAnimationFrame(() => this._reposition()); }

  _collect() {
    const found = [];
    const seen = new Set();
    const walk = (root) => {
      let nodes;
      try { nodes = root.querySelectorAll('*'); } catch { return; }
      for (const el of nodes) {
        if (el === this || this.contains(el) || el.closest?.('ascend-inspector')) continue;
        if (el.localName.includes('-') && !seen.has(el)) { seen.add(el); found.push(el); }
        if (this._pierce && el.shadowRoot) walk(el.shadowRoot);
      }
    };
    walk(document.body);
    return found;
  }

  _scan() {
    if (!this._root) return;
    const live = new Set(this._collect());

    // remove boxes for elements that disappeared
    for (const [el, rec] of this._targets) {
      if (!live.has(el)) { rec.box.remove(); this._targets.delete(el); }
    }
    // add / reclassify
    for (const el of live) {
      let rec = this._targets.get(el);
      if (!rec) {
        const box = document.createElement('div');
        box.className = 'box';
        const label = document.createElement('span');
        label.className = 'lab';
        box.appendChild(label);
        this._overlay.appendChild(box);
        rec = { box, label, cls: null };
        this._targets.set(el, rec);
      }
      rec.cls = this.classify(el);
    }
    this._reposition();
    this._updatePanel();
  }

  _reposition() {
    if (!this._root) return;
    const show = this._enabled;
    for (const [el, rec] of this._targets) {
      const { box, label, cls } = rec;
      const visible = show && this._filters[cls.library] && el.isConnected;
      if (!visible) { box.style.display = 'none'; continue; }
      const r = el.getBoundingClientRect();
      if (r.width === 0 && r.height === 0) { box.style.display = 'none'; continue; }
      box.style.display = 'block';
      box.style.transform = `translate(${r.left}px, ${r.top}px)`;
      box.style.width = `${r.width}px`;
      box.style.height = `${r.height}px`;
      box.style.setProperty('--c', this._cfg.colors[cls.library]);
      box.classList.toggle('active', el === this._active);
      label.textContent = `${el.localName}`;
      label.style.display = this._showLabels ? 'inline-block' : 'none';
    }
  }

  // ---- hover inspect --------------------------------------------------------
  _targetFrom(node) {
    let n = node;
    while (n) {
      if (this._targets.has(n)) return n;
      n = n.parentNode instanceof ShadowRoot ? n.parentNode.host : n.parentElement ?? (n.getRootNode?.() instanceof ShadowRoot ? n.getRootNode().host : null);
    }
    return null;
  }

  _hover(e) {
    if (!this._enabled) return;
    const under = this.shadowRoot ? document.elementFromPoint(e.clientX, e.clientY) : null;
    const el = under ? this._targetFrom(under) : null;
    if (el === this._active) { if (el) this._moveTip(e, el); return; }
    this._active = el;
    this._reposition();
    if (el) this._showTip(e, el); else this._tip.style.display = 'none';
  }

  _showTip(e, el) {
    const cls = this._targets.get(el).cls;
    const r = el.getBoundingClientRect();
    this._tip.innerHTML =
      `<b style="color:${this._cfg.colors[cls.library]}">${this._cfg.labels[cls.library]}</b>` +
      `<code>&lt;${el.localName}&gt;</code>` +
      `<span>${cls.confidence} confidence &middot; ${cls.reason}</span>` +
      `<span>${Math.round(r.width)} &times; ${Math.round(r.height)}</span>`;
    this._tip.style.display = 'block';
    this._moveTip(e);
  }

  _moveTip(e) {
    const pad = 14;
    const w = this._tip.offsetWidth, h = this._tip.offsetHeight;
    let x = e.clientX + pad, y = e.clientY + pad;
    if (x + w > innerWidth) x = e.clientX - w - pad;
    if (y + h > innerHeight) y = e.clientY - h - pad;
    this._tip.style.transform = `translate(${x}px, ${y}px)`;
  }

  // ---- panel ----------------------------------------------------------------
  _applyTheme() {
    if (!this._root) return;
    for (const lib of LIBRARIES) this.style.setProperty(`--c-${lib}`, this._cfg.colors[lib]);
    this._root.host.style.setProperty('--c-ascend', this._cfg.colors.ascend);
    this._root.host.style.setProperty('--c-webawesome', this._cfg.colors.webawesome);
    this._root.host.style.setProperty('--c-unknown', this._cfg.colors.unknown);
  }

  _wirePanel() {
    const $ = (id) => this._root.getElementById(id);
    $('master').addEventListener('change', (e) => this._setEnabled(e.target.checked));
    $('labels').addEventListener('change', (e) => { this._showLabels = e.target.checked; this._reposition(); });
    $('pierce').addEventListener('change', (e) => { this._pierce = e.target.checked; this._scan(); });
    for (const lib of LIBRARIES) {
      $(`f-${lib}`).addEventListener('change', (e) => { this._filters[lib] = e.target.checked; this._reposition(); });
    }
    $('rescan').addEventListener('click', () => this._scan());
    $('copy').addEventListener('click', () => this._copyReport($('copy')));
    $('collapse').addEventListener('click', () => this._panel.classList.toggle('collapsed'));
  }

  _setEnabled(on) {
    this._enabled = on;
    this._root.getElementById('master').checked = on;
    this._panel.classList.toggle('off', !on);
    if (!on) this._tip.style.display = 'none';
    this._reposition();
  }

  _counts() {
    const n = { ascend: 0, webawesome: 0, unknown: 0 };
    for (const { cls } of this._targets.values()) n[cls.library]++;
    return n;
  }

  _updatePanel() {
    const n = this._counts();
    const known = n.ascend + n.webawesome;
    const pct = known ? Math.round((n.ascend / known) * 100) : 0;
    const $ = (id) => this._root.getElementById(id);
    $('n-ascend').textContent = n.ascend;
    $('n-webawesome').textContent = n.webawesome;
    $('n-unknown').textContent = n.unknown;
    $('pct').textContent = `${pct}%`;
    $('bar-a').style.width = `${known ? (n.ascend / known) * 100 : 0}%`;
    $('bar-w').style.width = `${known ? (n.webawesome / known) * 100 : 0}%`;
    $('adopt-note').textContent = known
      ? `${n.ascend} of ${known} on Ascend`
      : 'no library components found';
  }

  async _copyReport(btn) {
    const report = [...this._targets].map(([el, rec]) => ({
      tag: el.localName, ...rec.cls,
      rect: (({ x, y, width, height }) => ({ x: Math.round(x), y: Math.round(y), width: Math.round(width), height: Math.round(height) }))(el.getBoundingClientRect()),
    }));
    const payload = { generatedAt: new Date().toISOString(), counts: this._counts(), components: report };
    const text = JSON.stringify(payload, null, 2);
    try { await navigator.clipboard.writeText(text); btn.textContent = 'Copied'; }
    catch { console.log(text); btn.textContent = 'Logged'; }
    setTimeout(() => (btn.textContent = 'Copy report'), 1400);
  }

  // ---- draggable panel ------------------------------------------------------
  _makeDraggable() {
    const head = this._root.getElementById('head');
    let sx, sy, ox, oy, dragging = false;
    head.addEventListener('pointerdown', (e) => {
      if (e.target.closest('.switch, button')) return;
      dragging = true; head.setPointerCapture(e.pointerId);
      const r = this._panel.getBoundingClientRect();
      sx = e.clientX; sy = e.clientY; ox = r.left; oy = r.top;
      this._panel.style.right = 'auto'; this._panel.style.bottom = 'auto';
    });
    head.addEventListener('pointermove', (e) => {
      if (!dragging) return;
      this._panel.style.left = `${Math.max(0, ox + e.clientX - sx)}px`;
      this._panel.style.top = `${Math.max(0, oy + e.clientY - sy)}px`;
    });
    head.addEventListener('pointerup', (e) => { dragging = false; head.releasePointerCapture(e.pointerId); });
  }
}

const TEMPLATE = /* html */ `
<style>
  :host { --c-ascend:#6d5efc; --c-webawesome:#f5a524; --c-unknown:#94a3b8;
    all: initial; font-family: ui-sans-serif, system-ui, sans-serif; }
  #overlay { position: fixed; inset: 0; pointer-events: none; z-index: 2147483000; }
  .box { position: absolute; top: 0; left: 0; box-sizing: border-box;
    border: 2px solid var(--c); border-radius: 4px;
    background: color-mix(in srgb, var(--c) 8%, transparent);
    transition: box-shadow .12s ease; will-change: transform; }
  .box.active { box-shadow: 0 0 0 2px #fff, 0 0 0 4px var(--c), 0 8px 24px color-mix(in srgb, var(--c) 45%, transparent);
    background: color-mix(in srgb, var(--c) 16%, transparent); z-index: 1; }
  .lab { position: absolute; top: -1px; left: -1px; transform: translateY(-100%);
    font: 600 10px/1.6 ui-monospace, monospace; color: #fff; background: var(--c);
    padding: 0 5px; border-radius: 3px 3px 3px 0; white-space: nowrap; letter-spacing: .02em; }

  #tip { position: fixed; top: 0; left: 0; z-index: 2147483100; display: none; pointer-events: none;
    background: #0f1117; color: #e6e9f0; border: 1px solid #262b36; border-radius: 8px;
    padding: 8px 10px; font-size: 12px; line-height: 1.5; max-width: 260px;
    box-shadow: 0 12px 32px rgba(0,0,0,.4); will-change: transform; }
  #tip code { display: block; color: #9aa4b8; font: 12px ui-monospace, monospace; margin: 2px 0; }
  #tip span { display: block; color: #8b93a3; font-size: 11px; }

  #panel { position: fixed; right: 20px; bottom: 20px; z-index: 2147483200; width: 244px;
    background: #14161c; color: #e6e9f0; border: 1px solid #2a2f3a; border-radius: 14px;
    box-shadow: 0 20px 50px rgba(0,0,0,.45); overflow: hidden; pointer-events: auto;
    font-size: 13px; user-select: none; }
  #panel.off { opacity: .82; }
  #head { display: flex; align-items: center; gap: 8px; padding: 11px 13px; cursor: grab;
    background: linear-gradient(180deg,#191c24,#14161c); border-bottom: 1px solid #23272f; }
  #head:active { cursor: grabbing; }
  #head .dot { width: 8px; height: 8px; border-radius: 50%;
    background: conic-gradient(var(--c-ascend), var(--c-webawesome), var(--c-unknown), var(--c-ascend)); }
  #head h1 { font-size: 12.5px; font-weight: 650; margin: 0; letter-spacing: .01em; flex: 1; }
  #collapse { all: unset; cursor: pointer; color: #7a8496; font-size: 15px; padding: 0 4px; }
  #collapse:hover { color: #fff; }
  .switch { position: relative; width: 34px; height: 20px; flex: none; }
  .switch input { position: absolute; opacity: 0; width: 100%; height: 100%; margin: 0; cursor: pointer; }
  .track { position: absolute; inset: 0; background: #39404d; border-radius: 999px; transition: background .15s; }
  .track::after { content: ''; position: absolute; top: 2px; left: 2px; width: 16px; height: 16px;
    background: #fff; border-radius: 50%; transition: transform .15s; }
  .switch input:checked + .track { background: var(--c-ascend); }
  .switch input:checked + .track::after { transform: translateX(14px); }

  #body { padding: 13px; display: grid; gap: 13px; }
  #panel.collapsed #body { display: none; }

  .adopt { display: grid; gap: 7px; }
  .adopt .top { display: flex; align-items: baseline; justify-content: space-between; }
  .adopt .top b { font-size: 22px; font-weight: 700; }
  .adopt .top small { color: #8b93a3; font-size: 11px; }
  .bar { height: 8px; border-radius: 999px; background: #23272f; overflow: hidden; display: flex; }
  .bar i { display: block; height: 100%; }
  #bar-a { background: var(--c-ascend); }
  #bar-w { background: var(--c-webawesome); }
  #adopt-note { color: #8b93a3; font-size: 11px; }

  .rows { display: grid; gap: 4px; }
  .row { display: flex; align-items: center; gap: 8px; padding: 3px 4px; border-radius: 7px; }
  .row:hover { background: #1b1f27; }
  .row label { display: flex; align-items: center; gap: 8px; flex: 1; cursor: pointer; }
  .sw { width: 11px; height: 11px; border-radius: 3px; flex: none; }
  .row .k { flex: 1; }
  .row .v { font: 600 12px ui-monospace, monospace; color: #cdd4e6; }
  .row input { accent-color: currentColor; width: 14px; height: 14px; cursor: pointer; }

  .opts { display: grid; gap: 6px; border-top: 1px solid #23272f; padding-top: 11px; }
  .opt { display: flex; align-items: center; gap: 8px; color: #c2c9d6; cursor: pointer; }
  .opt input { accent-color: var(--c-ascend); width: 14px; height: 14px; }
  .actions { display: flex; gap: 8px; }
  .actions button { flex: 1; all: unset; text-align: center; cursor: pointer; padding: 7px 0;
    border-radius: 8px; font-size: 12px; font-weight: 600; background: #232834; color: #dfe4ee;
    border: 1px solid #2f3542; }
  .actions button:hover { background: #2c333f; }
  .hint { color: #6b7280; font-size: 10.5px; text-align: center; }
  kbd { font: 10px ui-monospace, monospace; background: #23272f; border: 1px solid #333a47;
    border-radius: 4px; padding: 0 4px; color: #aab2c0; }
</style>

<div id="overlay"></div>
<div id="tip"></div>

<div id="panel">
  <div id="head">
    <span class="dot"></span>
    <h1>Component Inspector</h1>
    <label class="switch"><input id="master" type="checkbox" checked /><span class="track"></span></label>
    <button id="collapse" title="Collapse">–</button>
  </div>
  <div id="body">
    <div class="adopt">
      <div class="top"><b id="pct">0%</b><small>Ascend adoption</small></div>
      <div class="bar"><i id="bar-a"></i><i id="bar-w"></i></div>
      <div id="adopt-note">scanning…</div>
    </div>

    <div class="rows">
      <div class="row"><label><span class="sw" style="background:var(--c-ascend)"></span>
        <span class="k">Ascend Awesome</span></label><span class="v" id="n-ascend">0</span>
        <input id="f-ascend" type="checkbox" checked style="color:var(--c-ascend)" /></div>
      <div class="row"><label><span class="sw" style="background:var(--c-webawesome)"></span>
        <span class="k">Web Awesome</span></label><span class="v" id="n-webawesome">0</span>
        <input id="f-webawesome" type="checkbox" checked style="color:var(--c-webawesome)" /></div>
      <div class="row"><label><span class="sw" style="background:var(--c-unknown)"></span>
        <span class="k">Unknown</span></label><span class="v" id="n-unknown">0</span>
        <input id="f-unknown" type="checkbox" checked style="color:var(--c-unknown)" /></div>
    </div>

    <div class="opts">
      <label class="opt"><input id="labels" type="checkbox" checked /> Show tag labels</label>
      <label class="opt"><input id="pierce" type="checkbox" /> Pierce shadow DOM (internals)</label>
      <div class="actions">
        <button id="rescan">Rescan</button>
        <button id="copy">Copy report</button>
      </div>
      <div class="hint"><kbd>Alt</kbd>+<kbd>A</kbd> toggle &middot; <kbd>Alt</kbd>+click to log</div>
    </div>
  </div>
</div>
`;

if (!customElements.get('ascend-inspector')) customElements.define('ascend-inspector', AscendInspector);
