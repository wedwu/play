# Ascend / Web Awesome Inspector (Edge extension)

Toggle the component inspector on any page from the toolbar, instead of hard-coding the
script into HTML. Built as a Manifest V3 extension, so it also loads in Chrome.

## Install (unpacked, for development)

1. Unzip this folder somewhere permanent.
2. Open `edge://extensions` (or `chrome://extensions`).
3. Turn on **Developer mode** (toggle, top-left in Edge / top-right in Chrome).
4. Click **Load unpacked** and select this folder (the one containing `manifest.json`).
5. Pin the extension from the toolbar puzzle-piece menu.

## Use

- Click the toolbar icon to open the popup, then **Turn on for this page**.
- Or press **Alt+Shift+A** to toggle without opening the popup.
- In the popup, set which tag prefixes count as Ascend (defaults to `ts-, aa-, ascend-`)
  and any exact tags to force-classify as Ascend (for overridden `wa-` tags). Changes apply
  live to the current page and are saved for next time.

## How it works

- The inspector is injected into the page's **MAIN world**, so `customElements.get()` sees the
  page's real Web Awesome / Ascend constructors. That keeps the constructor-name classification
  signal working, not just prefixes.
- It uses `activeTab`, so it only touches a page after you invoke it. No broad host permissions.

## Limitations

- Cannot run on browser-internal pages (`edge://`, `chrome://`, the extension gallery, the PDF
  viewer). The popup will say so.
- Closed shadow roots (`{ mode: 'closed' }`) cannot be pierced by anyone; components inside them
  are invisible to the scan. Web Awesome uses open roots, so it is unaffected.

## Files

- `manifest.json` — MV3 config, toolbar action, `Alt+Shift+A` command.
- `inspector.js` — the inspector custom element (guarded define; safe to inject repeatedly).
- `inject.js` — shared MAIN-world injection helpers.
- `background.js` — service worker for the keyboard command.
- `popup.html` / `popup.js` — toggle + configuration UI.
