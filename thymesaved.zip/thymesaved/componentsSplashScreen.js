import React, { useEffect, useRef } from 'react';
import { View, Image, Text, Animated, StyleSheet } from 'react-native';

export default function SplashScreen({ onFinish }) {
  const progress = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // Animate the bar from 0 to 100% over 2 seconds
    Animated.timing(progress, {
      toValue: 1,
      duration: 2000,
      useNativeDriver: false,
    }).start(() => onFinish());
  }, []);

  const width = progress.interpolate({
    inputRange: [0, 1],
    outputRange: ['0%', '100%'],
  });

  return (
    <View style={styles.container}>
      <Image source={require('../assets/your-logo.png')} style={styles.logo} />
      <Text style={styles.text}>Loading your inventory...</Text>
      <View style={styles.barBackground}>
        <Animated.View style={[styles.barFill, { width }]} />
      </View>
    </View>
  );
}