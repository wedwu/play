import "react-native-url-polyfill/auto";
import React from "react";
import * as SplashScreen from "expo-splash-screen";
import { useAuth } from "./hooks/useAuth";
import SplashImage from "./screens/SplashImage";
import LoginScreen from "./screens/LoginScreen";
import PantryApp from "./screens/PantryApp";

// Keep the native splash screen visible while we fetch resources.
SplashScreen.preventAutoHideAsync();

// Thin shell: pick the screen based on auth state. No rendering details
// or data logic live here — those moved into hooks/, api/, and screens/.
export default function App() {
  const { session, appReady, login } = useAuth();

  if (!appReady) return <SplashImage />;
  if (!session) return <LoginScreen onLogin={login} />;
  return <PantryApp />;
}
