import { supabase } from "../supabase";

// --- Pure Supabase calls for the items / inventory tables. ---

export const fetchInventory = async () => {
  const { data, error } = await supabase.from("inventory").select(`
      item_id, quantity, unit, min_quantity,
      items ( id, name, category )
    `);
  if (error) throw error;
  return data || [];
};

// Inserts the catalog row (items) then its stock-tracking row (inventory).
export const createItem = async ({
  name,
  category,
  unit,
  quantity,
  minQuantity,
}) => {
  const { data: itemData, error: itemError } = await supabase
    .from("items")
    .insert([{ name, category, default_unit: unit }])
    .select()
    .single();
  if (itemError) throw itemError;

  const { error: invError } = await supabase.from("inventory").insert([
    {
      item_id: itemData.id,
      quantity,
      unit,
      min_quantity: minQuantity,
    },
  ]);
  if (invError) throw invError;

  return itemData;
};

export const updateItem = async ({
  itemId,
  inventoryItemId,
  name,
  category,
  quantity,
  unit,
  minQuantity,
}) => {
  const { error: itemError } = await supabase
    .from("items")
    .update({ name, category })
    .eq("id", itemId);
  if (itemError) throw itemError;

  const { error: invError } = await supabase
    .from("inventory")
    .update({ quantity, unit, min_quantity: minQuantity })
    .eq("item_id", inventoryItemId);
  if (invError) throw invError;
};

// Clears the shopping_list + inventory rows before removing the parent item.
export const deleteItem = async ({ itemId, inventoryItemId }) => {
  await supabase.from("shopping_list").delete().eq("item_id", inventoryItemId);
  await supabase.from("inventory").delete().eq("item_id", inventoryItemId);

  const { error } = await supabase.from("items").delete().eq("id", itemId);
  if (error) throw error;
};

export const getInventoryQuantity = async (itemId) => {
  const { data, error } = await supabase
    .from("inventory")
    .select("quantity")
    .eq("item_id", itemId)
    .single();
  if (error) throw error;
  return data.quantity || 0;
};

export const setInventoryQuantity = async (itemId, quantity) => {
  const { error } = await supabase
    .from("inventory")
    .update({ quantity })
    .eq("item_id", itemId);
  if (error) throw error;
};
