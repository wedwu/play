import { supabase } from "../supabase";

// --- Pure Supabase auth/session calls. No React here. ---

export const getActiveSession = async () => {
  const {
    data: { session },
  } = await supabase.auth.getSession();
  return session;
};

export const getProfile = async (userId) => {
  const { data } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", userId)
    .single();
  return data;
};

export const onAuthStateChange = (callback) =>
  supabase.auth.onAuthStateChange(callback);

export const signInWithPassword = (email, password) =>
  supabase.auth.signInWithPassword({ email, password });
