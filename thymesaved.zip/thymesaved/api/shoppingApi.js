import { supabase } from "../supabase";

// --- Pure Supabase calls for the shopping_list table. ---

export const fetchShoppingList = async () => {
  const { data, error } = await supabase.from("shopping_list").select(`
      item_id, needed, purchased, quantity_needed, unit,
      items ( id, name, category )
    `);
  if (error) throw error;
  return data || [];
};

export const findShoppingItem = async (itemId) => {
  const { data, error } = await supabase
    .from("shopping_list")
    .select("item_id, quantity_needed")
    .eq("item_id", itemId)
    .maybeSingle();
  if (error) throw error;
  return data;
};

export const addShoppingItem = async ({ itemId, quantityNeeded, unit }) => {
  const { error } = await supabase.from("shopping_list").insert([
    {
      item_id: itemId,
      quantity_needed: quantityNeeded,
      unit,
      needed: false,
      purchased: false,
    },
  ]);
  if (error) throw error;
};

export const setQuantityNeeded = async (itemId, quantityNeeded) => {
  const { error } = await supabase
    .from("shopping_list")
    .update({ quantity_needed: quantityNeeded })
    .eq("item_id", itemId);
  if (error) throw error;
};

export const setNeeded = async (itemId, needed) => {
  const { error } = await supabase
    .from("shopping_list")
    .update({ needed })
    .eq("item_id", itemId);
  if (error) throw error;
};

export const removeShoppingItem = async (itemId) => {
  const { error } = await supabase
    .from("shopping_list")
    .delete()
    .eq("item_id", itemId);
  if (error) throw error;
};
