import React, { useState } from "react";
import { View } from "react-native";
import { usePantry } from "../hooks/usePantry";
import { styles } from "../theme/styles";
import NavTabs from "../components/NavTabs";
import AddItemModal from "../components/AddItemModal";
import EditItemModal from "../components/EditItemModal";
import InventoryScreen from "./InventoryScreen";
import ShoppingScreen from "./ShoppingScreen";

// Authenticated container: wires the usePantry logic into the two screens
// and the add/edit modals. Holds only view state (which modal is open).
const PantryApp = () => {
  const pantry = usePantry();
  const [addVisible, setAddVisible] = useState(false);
  const [editItem, setEditItem] = useState(null);

  return (
    <View style={styles.container}>
      <NavTabs
        current={pantry.currentScreen}
        onChange={pantry.setCurrentScreen}
      />

      {pantry.currentScreen === "inventory" ? (
        <InventoryScreen
          inventoryItems={pantry.inventoryItems}
          categoryFolders={pantry.categoryFolders}
          filteredInventory={pantry.filteredInventory}
          selectedCategory={pantry.selectedCategory}
          onSelectCategory={pantry.setSelectedCategory}
          onAdd={() => setAddVisible(true)}
          onEdit={setEditItem}
          onUse={pantry.useItem}
        />
      ) : (
        <ShoppingScreen
          shoppingItems={pantry.shoppingItems}
          onToggleVital={pantry.toggleVital}
          onGot={pantry.gotItem}
        />
      )}

      <AddItemModal
        visible={addVisible}
        onClose={() => setAddVisible(false)}
        onSubmit={pantry.addItem}
      />

      <EditItemModal
        item={editItem}
        onClose={() => setEditItem(null)}
        onSave={pantry.updateItem}
        onDelete={pantry.deleteItem}
      />
    </View>
  );
};

export default PantryApp;
