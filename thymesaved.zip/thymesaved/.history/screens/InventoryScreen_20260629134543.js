import React from "react";
import { FlatList, Text, TouchableOpacity, View } from "react-native";
import { styles } from "../theme/styles";

// Pure presentation: shows category folders, or the items inside the
// selected folder. All actions are delegated through props.
const InventoryScreen = ({
  inventoryItems,
  categoryFolders,
  filteredInventory,
  selectedCategory,
  onSelectCategory,
  onAdd,
  onEdit,
  onUse,
}) => {
  return (
    <View style={{ flex: 1 }}>
      <View style={styles.headerRow}>
        <Text style={styles.title}>ThymeSaved Pantry</Text>
        <TouchableOpacity style={styles.addButton} onPress={onAdd}>
          <Text style={styles.addButtonText}>＋ ADD</Text>
        </TouchableOpacity>
      </View>

      {selectedCategory === null ? (
        <>
          <Text style={styles.subtitle}>
            Select a category to browse your items:
          </Text>
          <FlatList
            data={categoryFolders}
            keyExtractor={(item) => item}
            contentContainerStyle={styles.listContent}
            renderItem={({ item }) => (
              <TouchableOpacity
                style={styles.categoryCard}
                onPress={() => onSelectCategory(item)}
              >
                <Text style={styles.categoryCardText}>📁 {item}</Text>
                <Text style={styles.categoryCount}>
                  (
                  {
                    inventoryItems.filter((i) => i.items?.category === item)
                      .length
                  }{" "}
                  items)
                </Text>
              </TouchableOpacity>
            )}
          />
        </>
      ) : (
        <>
          <View style={styles.categoryHeader}>
            <TouchableOpacity
              style={styles.backButton}
              onPress={() => onSelectCategory(null)}
            >
              <Text style={styles.backButtonText}>⬅ Back to Categories</Text>
            </TouchableOpacity>
            <Text style={styles.currentCategoryTitle}>
              📂 {selectedCategory}
            </Text>
          </View>

          <FlatList
            data={filteredInventory}
            keyExtractor={(item) => item.item_id}
            contentContainerStyle={styles.listContent}
            renderItem={({ item }) => (
              <View style={styles.itemRow}>
                <TouchableOpacity
                  style={{ flex: 2 }}
                  onPress={() => onEdit(item)}
                >
                  <Text style={styles.itemName}>
                    {item.items?.name || "Unknown"}
                  </Text>
                  <Text style={styles.editHintText}>
                    ✏️ Tap to edit or delete
                  </Text>
                </TouchableOpacity>
                <View style={styles.actionsRight}>
                  <Text style={styles.itemStock}>
                    {item.quantity} {item.unit}
                  </Text>
                  <TouchableOpacity
                    style={styles.useButton}
                    onPress={() => onUse(item.item_id, item.quantity)}
                  >
                    <Text style={styles.buttonText}>USE</Text>
                  </TouchableOpacity>
                </View>
              </View>
            )}
          />
        </>
      )}
    </View>
  );
};

export default InventoryScreen;
