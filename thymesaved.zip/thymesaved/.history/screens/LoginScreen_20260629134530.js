import React, { useState } from "react";
import { Text, TextInput, TouchableOpacity, View } from "react-native";
import { authStyles } from "../theme/styles";

// Presentational login gate. Auth logic lives in useAuth (passed via onLogin).
const LoginScreen = ({ onLogin }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  return (
    <View style={authStyles.container}>
      <Text style={authStyles.title}>🌿 ThymeSaved Pantry</Text>
      <Text style={authStyles.subtitle}>
        Sign in to access your shared household inventory
      </Text>

      <TextInput
        style={authStyles.input}
        placeholder="Email Address"
        autoCapitalize="none"
        value={email}
        onChangeText={setEmail}
        placeholderTextColor="#888"
      />
      <TextInput
        style={[authStyles.input, authStyles.inputSpaced]}
        placeholder="Password"
        secureTextEntry
        autoCapitalize="none"
        value={password}
        onChangeText={setPassword}
        placeholderTextColor="#888"
      />

      <TouchableOpacity
        style={authStyles.button}
        onPress={() => onLogin(email, password)}
      >
        <Text style={authStyles.buttonText}>Log In</Text>
      </TouchableOpacity>
    </View>
  );
};

export default LoginScreen;
