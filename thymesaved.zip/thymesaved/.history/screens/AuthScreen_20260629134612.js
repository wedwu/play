import React, { useState } from "react";
import {
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  Alert,
} from "react-native";
import { supabase } from "../supabaseClient"; // Adjust this path to your Supabase client configuration

const AuthScreen = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [inviteCode, setInviteCode] = useState("");

  // Modes: 'login' | 'create_household' | 'join_household'
  const [mode, setMode] = useState("login");
  const [loading, setLoading] = useState(false);

  // Handle standard Email/Password Login
  const handleLogin = async () => {
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    setLoading(false);
    if (error) Alert.alert("Login Error", error.message);
  };

  // Handle Initial Registration (Creates a brand new household row)
  const handleCreateHousehold = async () => {
    if (!displayName) return Alert.alert("Error", "Please enter your name.");
    setLoading(true);

    // 1. Sign up user in Supabase Auth
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email,
      password,
    });
    if (authError) {
      setLoading(false);
      return Alert.alert("Sign Up Error", authError.message);
    }

    try {
      // 2. Create a new Household row
      const { data: household, error: householdError } = await supabase
        .from("households")
        .insert([{ name: `${displayName}'s Household` }])
        .select()
        .single();
      if (householdError) throw householdError;

      // 3. Link profile to the new household
      const { error: profileError } = await supabase
        .from("profiles")
        .update({ display_name: displayName, household_id: household.id })
        .eq("id", authData.user.id);
      if (profileError) throw profileError;
    } catch (err) {
      Alert.alert("Database Error", err.message);
    } finally {
      setLoading(false);
    }
  };

  // Handle Joining an Existing Household (Using the invite code)
  const handleJoinHousehold = async () => {
    if (!displayName || !inviteCode)
      return Alert.alert("Error", "Fill out all fields.");
    setLoading(true);

    try {
      // 1. Verify invite code
      const { data: invite, error: inviteError } = await supabase
        .from("invitations")
        .select("household_id")
        .eq("code", inviteCode.trim().toUpperCase())
        .single();

      if (inviteError || !invite)
        throw new Error("Invalid or expired invitation code.");

      // 2. Sign up user in Supabase Auth
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email,
        password,
      });
      if (authError) throw authError;

      // 3. Update profile row to hook into existing household
      const { error: profileError } = await supabase
        .from("profiles")
        .update({
          display_name: displayName,
          household_id: invite.household_id,
        })
        .eq("id", authData.user.id);
      if (profileError) throw profileError;
    } catch (err) {
      Alert.alert("Error", err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>🌿 ThymeSaved</Text>

      {mode !== "login" && (
        <TextInput
          style={styles.input}
          placeholder="Your Name"
          value={displayName}
          onChangeText={setDisplayName}
        />
      )}

      <TextInput
        style={styles.input}
        placeholder="Email"
        autoCapitalize="none"
        value={email}
        onChangeText={setEmail}
      />

      <TextInput
        style={styles.input}
        placeholder="Password"
        secureTextEntry
        autoCapitalize="none"
        value={password}
        onChangeText={setPassword}
      />

      {mode === "join_household" && (
        <TextInput
          style={styles.input}
          placeholder="Invite Code (e.g., THYME1)"
          autoCapitalize="characters"
          value={inviteCode}
          onChangeText={setInviteCode}
        />
      )}

      {mode === "login" && (
        <TouchableOpacity
          style={styles.button}
          onPress={handleLogin}
          disabled={loading}
        >
          <Text style={styles.buttonText}>
            {loading ? "Logging in..." : "Log In"}
          </Text>
        </TouchableOpacity>
      )}

      {mode === "create_household" && (
        <TouchableOpacity
          style={[styles.button, styles.accentButton]}
          onPress={handleCreateHousehold}
          disabled={loading}
        >
          <Text style={styles.buttonText}>
            {loading ? "Creating..." : "Create Household"}
          </Text>
        </TouchableOpacity>
      )}

      {mode === "join_household" && (
        <TouchableOpacity
          style={[styles.button, styles.accentButton]}
          onPress={handleJoinHousehold}
          disabled={loading}
        >
          <Text style={styles.buttonText}>
            {loading ? "Joining..." : "Join Household"}
          </Text>
        </TouchableOpacity>
      )}

      {/* Mode Switchers */}
      <View style={styles.toggleContainer}>
        {mode === "login" ? (
          <>
            <TouchableOpacity onPress={() => setMode("create_household")}>
              <Text style={styles.toggleText}>Create a New Household</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => setMode("join_household")}>
              <Text style={styles.toggleText}>Join an Existing Household</Text>
            </TouchableOpacity>
          </>
        ) : (
          <TouchableOpacity onPress={() => setMode("login")}>
            <Text style={styles.toggleText}>Back to Login</Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    padding: 20,
    backgroundColor: "#fcfbf7",
  },
  title: {
    fontSize: 32,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 40,
    color: "#2c4c38",
  },
  input: {
    backgroundColor: "#fff",
    padding: 15,
    borderRadius: 8,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: "#e2e8f0",
  },
  button: {
    backgroundColor: "#2c4c38",
    padding: 15,
    borderRadius: 8,
    alignItems: "center",
    marginTop: 10,
  },
  accentButton: { backgroundColor: "#4a7c59" },
  buttonText: { color: "#fff", fontSize: 16, fontWeight: "bold" },
  toggleContainer: { marginTop: 25, alignItems: "center", gap: 12 },
  toggleText: { color: "#4a7c59", fontWeight: "600" },
});

export default AuthScreen;
