import React from "react";
import { Image, View } from "react-native";
import { splashStyles } from "../theme/styles";

// Branded hold screen shown until the app-ready timer fires.
export default function SplashImage() {
  return (
    <View style={splashStyles.container}>
      <Image source={require("../assets/splash.png")} style={splashStyles.image} />
    </View>
  );
}
