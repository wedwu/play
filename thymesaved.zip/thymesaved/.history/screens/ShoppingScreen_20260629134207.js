import React from "react";
import { FlatList, Text, TouchableOpacity, View } from "react-native";
import { styles } from "../theme/styles";

// Pure presentation: the smart shopping list. Actions delegated via props.
export default function ShoppingScreen({ shoppingItems, onToggleVital, onGot }) {
  return (
    <View style={{ flex: 1 }}>
      <Text style={styles.title}>Smart Shopping List</Text>
      <Text style={styles.subtitle}>Items flagged for purchase</Text>
      <FlatList
        data={shoppingItems}
        keyExtractor={(item) => item.item_id}
        contentContainerStyle={styles.listContent}
        renderItem={({ item }) => (
          <View style={[styles.itemRow, item.needed && styles.vitalRowBorder]}>
            <View style={{ flex: 1.5 }}>
              <View style={{ flexDirection: "row", alignItems: "center" }}>
                <Text style={styles.itemName}>
                  {item.items?.name || "Unknown"}
                </Text>
                {item.needed && <Text style={styles.vitalBadge}>! VITAL</Text>}
              </View>
              <Text style={styles.categoryLabel}>
                Needed: {item.quantity_needed} {item.unit} (
                {item.items?.category})
              </Text>
            </View>
            <View style={styles.shoppingActions}>
              <TouchableOpacity
                style={[
                  styles.vitalButton,
                  item.needed && styles.vitalActiveButton,
                ]}
                onPress={() => onToggleVital(item.item_id, item.needed)}
              >
                <Text
                  style={[styles.buttonText, item.needed && { color: "#fff" }]}
                >
                  VITAL
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.gotButton}
                onPress={() => onGot(item.item_id)}
              >
                <Text style={styles.buttonText}>GOT</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      />
    </View>
  );
}
