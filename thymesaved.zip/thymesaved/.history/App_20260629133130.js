import "react-native-url-polyfill/auto";
import React, { useEffect, useState } from "react";
import {
  StyleSheet,
  Text,
  View,
  Image,
  FlatList,
  ActivityIndicator,
  TouchableOpacity,
  Alert,
  StatusBar,
  Platform,
  Modal,
  TextInput,
} from "react-native";
import { supabase } from "./supabase";
import * as SplashScreen from "expo-splash-screen";

import { masterCategories } from "./const/index.ts";

// Keep the splash screen visible while we fetch resources
SplashScreen.preventAutoHideAsync();

export default function App() {
  const [currentScreen, setCurrentScreen] = useState("inventory"); // 'inventory' or 'shopping'
  const [inventoryItems, setInventoryItems] = useState([]);
  const [shoppingItems, setShoppingItems] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(null); // Tracks the active category folder

  // --- LOGIN STATES ---
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [appReady, setAppReady] = useState(false); // <--- Added holding state here
  const [authEmail, setAuthEmail] = useState("");
  const [authPassword, setAuthPassword] = useState("");

  // Form States for Adding New Items
  const [modalVisible, setModalVisible] = useState(false);
  const [newItemName, setNewItemName] = useState("");
  const [newItemCategory, setNewItemCategory] = useState(masterCategories[12]); // Default to "Herbs"
  const [newItemQty, setNewItemQty] = useState("1");
  const [newItemUnit, setNewItemUnit] = useState("packets");
  const [newItemMinQty, setNewItemMinQty] = useState("1");

  // States for Editing / Deleting Items
  const [editModalVisible, setEditModalVisible] = useState(false);
  const [selectedEditItem, setSelectedEditItem] = useState(null); // Holds the item object being edited
  const [editItemName, setEditItemName] = useState("");
  const [editItemCategory, setEditItemCategory] = useState("");
  const [editItemQty, setEditItemQty] = useState("");
  const [editItemUnit, setEditItemUnit] = useState("");
  const [editItemMinQty, setEditItemMinQty] = useState("");

  useEffect(() => {
    // See if a user session is already active on this device
    supabase.auth.getSession().then(({ data: { session: activeSession } }) => {
      setSession(activeSession);
      if (activeSession) {
        supabase
          .from("profiles")
          .select("*")
          .eq("id", activeSession.user.id)
          .single()
          .then(({ data: profData }) => {
            if (profData) setProfile(profData);
            SplashScreen.hideAsync();
          });
      } else {
        SplashScreen.hideAsync();
      }
    });

    // Automatically listen for manual logins/logouts
    const { data: authListener } = supabase.auth.onAuthStateChange(
      (_event, currentSession) => {
        setSession(currentSession);
        if (!currentSession) setProfile(null);
      },
    );

    // Forced preview timer to hold the image on screen
    const timer = setTimeout(() => {
      setAppReady(true);
    }, 2500);

    return () => {
      clearTimeout(timer);
      authListener.subscription.unsubscribe();
    };
  }, []);
  // Login engine function
  async function handleAuthLogin() {
    if (!authEmail || !authPassword) {
      return Alert.alert(
        "Missing Fields",
        "Please enter both email and password.",
      );
    }
    const { error } = await supabase.auth.signInWithPassword({
      email: authEmail,
      password: authPassword,
    });
    if (error) Alert.alert("Login Error", error.message);
  }
  useEffect(() => {
    fetchData();
  }, [currentScreen]);

  async function fetchData() {
    if (currentScreen === "inventory") {
      await fetchInventory();
    } else {
      await fetchShoppingList();
    }
  }

  async function fetchInventory() {
    try {
      const { data, error } = await supabase.from("inventory").select(`
          item_id, quantity, unit, min_quantity,
          items ( id, name, category )
        `);
      if (error) throw error;
      setInventoryItems(data || []);
    } catch (error) {
      console.error("Error fetching inventory:", error.message);
    }
  }

  async function fetchShoppingList() {
    try {
      const { data, error } = await supabase.from("shopping_list").select(`
          item_id, needed, purchased, quantity_needed, unit,
          items ( id, name, category )
        `);
      if (error) throw error;
      setShoppingItems(data || []);
    } catch (error) {
      console.error("Error fetching shopping list:", error.message);
    }
  }

  // UPDATED FIX FOR QUANTITY SYNC ISSUES
  async function handleAddItem() {
    if (!newItemName.trim()) {
      Alert.alert("Missing Name", "Please type an item name before saving.");
    }
    try {
      const cleanUnit = newItemUnit.trim() || "pcs";
      const cleanQty = parseInt(newItemQty, 10) || 0;
      const cleanMinQty = parseInt(newItemMinQty, 10) || 0;

      // Step A: Insert into parent item list
      const { data: itemData, error: itemError } = await supabase
        .from("items")
        .insert([
          {
            name: newItemName.trim(),
            category: newItemCategory,
            default_unit: cleanUnit,
          },
        ])
        .select()
        .single();

      if (itemError) throw itemError;

      // Step B: Direct integer parsing for the inventory stock tracking row
      const { error: invError } = await supabase.from("inventory").insert([
        {
          item_id: itemData.id,
          quantity: cleanQty,
          unit: cleanUnit,
          min_quantity: cleanMinQty,
        },
      ]);

      if (invError) throw invError;

      // Reset form variables completely
      setNewItemName("");
      setNewItemQty("1");
      setNewItemMinQty("1");
      setModalVisible(false);

      // Instantly open the newly populated folder view
      setSelectedCategory(newItemCategory);
      await fetchData();
    } catch (error) {
      Alert.alert("Database Error", error.message);
    } finally {
    }
  }

  // Open Edit Panel & Pre-populate inputs
  function openEditModal(item) {
    setSelectedEditItem(item);
    setEditItemName(item.items?.name || "");
    setEditItemCategory(item.items?.category || "Herbs");
    setEditItemQty(String(item.quantity || 0));
    setEditItemUnit(item.unit || "pcs");
    setEditItemMinQty(String(item.min_quantity || 0));
    setEditModalVisible(true);
  }

  // 1. CHIP-SHARP UPDATE LOGIC
  async function handleUpdateItem() {
    if (!editItemName.trim()) {
      Alert.alert("Missing Name", "Item name cannot be blank.");
    }

    try {
      // The exact database IDs
      const globalItemId = selectedEditItem.items.id; // ID in 'items' table
      const inventoryItemId = selectedEditItem.item_id; // ID in 'inventory' table

      // Step A: Update basic catalog traits in 'items'
      const { error: itemError } = await supabase
        .from("items")
        .update({
          name: editItemName.trim(),
          category: editItemCategory,
        })
        .eq("id", globalItemId);

      if (itemError) throw itemError;

      // Step B: Update specific stock values in 'inventory'
      const { error: invError } = await supabase
        .from("inventory")
        .update({
          quantity: parseInt(editItemQty, 10) || 0,
          unit: editItemUnit.trim() || "pcs",
          min_quantity: parseInt(editItemMinQty, 10) || 0,
        })
        .eq("item_id", inventoryItemId); // Targets the correct foreign key column

      if (invError) throw invError;

      setEditModalVisible(false);
      setSelectedEditItem(null);

      // If category changed, reset view to main folder selection
      if (editItemCategory !== selectedCategory) {
        setSelectedCategory(null);
      }

      await fetchData();
      Alert.alert("Success", "Item updated beautifully.");
    } catch (error) {
      Alert.alert("Update Error", error.message);
    } finally {
    }
  }

  // 2. FOOLPROOF BULLET DELETION LOGIC
  async function handleDeleteItem() {
    Alert.alert(
      "Confirm Deletion",
      `Are you absolutely sure you want to remove "${editItemName}" from your pantry entirely?`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: async () => {
            try {
              const globalItemId = selectedEditItem.items.id;
              const inventoryItemId = selectedEditItem.item_id;

              // Step A: Clear active shopping list triggers if any exist
              await supabase
                .from("shopping_list")
                .delete()
                .eq("item_id", inventoryItemId);

              // Step B: Clear inventory stock tracking row
              await supabase
                .from("inventory")
                .delete()
                .eq("item_id", inventoryItemId);

              // Step C: Delete parent row in items directory
              const { error: itemDeleteError } = await supabase
                .from("items")
                .delete()
                .eq("id", globalItemId);

              if (itemDeleteError) throw itemDeleteError;

              setEditModalVisible(false);
              setSelectedEditItem(null);
              await fetchData();
              Alert.alert(
                "Deleted",
                "Item completely cleared from your system.",
              );
            } catch (error) {
              Alert.alert("Deletion Error", error.message);
            } finally {
            }
          },
        },
      ],
    );
  }

  // 1. UPDATED: SMART LOW-STOCK AUTOMATION
  async function handleUseItem(itemId, currentQty) {
    if (currentQty <= 0) {
      Alert.alert("Out of stock!", "This item is already at 0.");
    }
    const newQty = currentQty - 1;
    try {
      // Deduct 1 from inventory
      const { error: updateError } = await supabase
        .from("inventory")
        .update({ quantity: newQty })
        .eq("item_id", itemId);

      if (updateError) throw updateError;

      // Update local state instantly
      setInventoryItems((prev) =>
        prev.map((item) =>
          item.item_id === itemId ? { ...item, quantity: newQty } : item,
        ),
      );

      const modifiedItem = inventoryItems.find(
        (item) => item.item_id === itemId,
      );
      const minQty = modifiedItem?.min_quantity || 0;

      // Check if we hit or dropped below the threshold
      if (newQty <= minQty) {
        // OPTION A MATH: Calculate exactly how many are needed to get back to minimum
        const exactQuantityNeeded = minQty - newQty;

        // If we are at the minimum exactly but not below, we need at least 1 to restock
        const finalNeeded = exactQuantityNeeded === 0 ? 1 : exactQuantityNeeded;

        // Check if it's already on the shopping list
        const { data: existingShopItem, error: checkError } = await supabase
          .from("shopping_list")
          .select("item_id, quantity_needed")
          .eq("item_id", itemId)
          .maybeSingle();

        if (checkError) throw checkError;

        if (!existingShopItem) {
          // Add to shopping list with the exact calculated missing quantity
          const { error: insertError } = await supabase
            .from("shopping_list")
            .insert([
              {
                item_id: itemId,
                quantity_needed: finalNeeded,
                unit: modifiedItem?.unit || "pcs",
                needed: false,
                purchased: false,
              },
            ]);

          if (insertError) throw insertError;
          Alert.alert(
            "Low Stock Alert!",
            `"${modifiedItem?.items?.name}" dropped to ${newQty}. Need ${finalNeeded} more to hit your minimum.`,
          );
        } else {
          // If it's already there, update the needed quantity dynamically as you keep using it
          await supabase
            .from("shopping_list")
            .update({ quantity_needed: finalNeeded })
            .eq("item_id", itemId);
        }
      }
    } catch (error) {
      Alert.alert("Automation Error", error.message);
    }
  }

  async function handleToggleVital(itemId, currentNeededStatus) {
    try {
      const { error } = await supabase
        .from("shopping_list")
        .update({ needed: !currentNeededStatus })
        .eq("item_id", itemId);
      if (error) throw error;
      setShoppingItems((prev) =>
        prev.map((item) =>
          item.item_id === itemId
            ? { ...item, needed: !currentNeededStatus }
            : item,
        ),
      );
    } catch (error) {
      console.error(error.message);
    }
  }

  // 2. UPDATED: CLOSED-LOOP RESTOCKING LOGIC
  async function handleGotItem(itemId) {
    try {
      // Find the item in our shopping list state to see how many we are buying
      const shopItem = shoppingItems.find((item) => item.item_id === itemId);
      if (!shopItem) {
        Alert.alert(
          "Restock Error",
          "This item is no longer on the shopping list.",
        );
        return;
      }
      const amountBought = shopItem.quantity_needed || 1;

      // Step A: Find the current stock in inventory
      const { data: invData, error: invFetchError } = await supabase
        .from("inventory")
        .select("quantity")
        .eq("item_id", itemId)
        .single();

      if (invFetchError) throw invFetchError;

      const newPantryTotal = (invData.quantity || 0) + amountBought;

      // Step B: Update the main pantry inventory with the restocked total
      const { error: invUpdateError } = await supabase
        .from("inventory")
        .update({ quantity: newPantryTotal })
        .eq("item_id", itemId);

      if (invUpdateError) throw invUpdateError;

      // Step C: Delete the item from the shopping list table
      const { error: shopDeleteError } = await supabase
        .from("shopping_list")
        .delete()
        .eq("item_id", itemId);

      if (shopDeleteError) throw shopDeleteError;

      // Refresh data to update both screens smoothly
      await fetchData();
      Alert.alert(
        "Restocked!",
        `Added ${amountBought} back to your pantry inventory.`,
      );
    } catch (error) {
      Alert.alert("Restock Error", error.message);
    } finally {
    }
  }

  const activeCategories = inventoryItems.map((item) => item.items?.category);
  const finalCategoryFolders = masterCategories.filter((category) =>
    activeCategories.includes(category),
  );
  const filteredInventory = inventoryItems.filter(
    (item) => item.items?.category === selectedCategory,
  );

  if (!appReady) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: "#F4F6F4",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Image
          source={require("./assets/splash.png")}
          style={{ width: "100%", height: "100%", resizeMode: "contain" }}
        />
      </View>
    );
  }

  // GATE: If you aren't logged in yet, show the Login Screen
  if (!session) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: "#fcfcfc",
          justifyContent: "center",
          paddingHorizontal: 30,
        }}
      >
        <Text
          style={{
            fontSize: 24,
            fontWeight: "bold",
            color: "#2C3E50",
            textAlign: "center",
            marginBottom: 10,
          }}
        >
          🌿 ThymeSaved Pantry
        </Text>
        <Text
          style={{
            fontSize: 14,
            color: "#7F8C8D",
            textAlign: "center",
            marginBottom: 30,
          }}
        >
          Sign in to access your shared household inventory
        </Text>

        <TextInput
          style={{
            backgroundColor: "#fff",
            padding: 15,
            borderRadius: 8,
            borderWidth: 1,
            borderColor: "#ddd",
            color: "#000",
          }}
          placeholder="Email Address"
          autoCapitalize="none"
          value={authEmail}
          onChangeText={setAuthEmail}
          placeholderTextColor="#888"
        />
        <TextInput
          style={{
            backgroundColor: "#fff",
            padding: 15,
            borderRadius: 8,
            borderWidth: 1,
            borderColor: "#ddd",
            color: "#000",
            marginTop: 12,
          }}
          placeholder="Password"
          secureTextEntry
          autoCapitalize="none"
          value={authPassword}
          onChangeText={setAuthPassword}
          placeholderTextColor="#888"
        />

        <TouchableOpacity
          style={{
            backgroundColor: "#4CAF50",
            padding: 15,
            borderRadius: 8,
            alignItems: "center",
            marginTop: 20,
          }}
          onPress={handleAuthLogin}
        >
          <Text style={{ color: "#fff", fontWeight: "bold", fontSize: 16 }}>
            Log In
          </Text>
        </TouchableOpacity>
      </View>
    );
  }

  // 2. MAIN UI: This block ONLY runs if loading is false
  return (
    <View style={styles.container}>
      {/* 1. NAVIGATION TABS */}
      <View style={styles.navTabs}>
        <TouchableOpacity
          style={[
            styles.tab,
            currentScreen === "inventory" && styles.activeTab,
          ]}
          onPress={() => setCurrentScreen("inventory")}
        >
          <Text
            style={[
              styles.tabText,
              currentScreen === "inventory" && styles.activeTabText,
            ]}
          >
            Pantry Inventory
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, currentScreen === "shopping" && styles.activeTab]}
          onPress={() => setCurrentScreen("shopping")}
        >
          <Text
            style={[
              styles.tabText,
              currentScreen === "shopping" && styles.activeTabText,
            ]}
          >
            Shopping List
          </Text>
        </TouchableOpacity>
      </View>

      {/* 2. PANTRY INVENTORY MODULE */}
      {currentScreen === "inventory" && (
        <View style={{ flex: 1 }}>
          <View style={styles.headerRow}>
            <Text style={styles.title}>ThymeSaved Pantry</Text>
            <TouchableOpacity
              style={styles.addButton}
              onPress={() => setModalVisible(true)}
            >
              <Text style={styles.addButtonText}>＋ ADD</Text>
            </TouchableOpacity>
          </View>

          {selectedCategory === null ? (
            <>
              <Text style={styles.subtitle}>
                Select a category to browse your items:
              </Text>
              <FlatList
                data={finalCategoryFolders}
                keyExtractor={(item) => item}
                contentContainerStyle={styles.listContent}
                renderItem={({ item }) => (
                  <TouchableOpacity
                    style={styles.categoryCard}
                    onPress={() => setSelectedCategory(item)}
                  >
                    <Text style={styles.categoryCardText}>📁 {item}</Text>
                    <Text style={styles.categoryCount}>
                      (
                      {
                        inventoryItems.filter((i) => i.items?.category === item)
                          .length
                      }{" "}
                      items)
                    </Text>
                  </TouchableOpacity>
                )}
              />
            </>
          ) : (
            <>
              <View style={styles.categoryHeader}>
                <TouchableOpacity
                  style={styles.backButton}
                  onPress={() => setSelectedCategory(null)}
                >
                  <Text style={styles.backButtonText}>
                    ⬅ Back to Categories
                  </Text>
                </TouchableOpacity>
                <Text style={styles.currentCategoryTitle}>
                  📂 {selectedCategory}
                </Text>
              </View>

              <FlatList
                data={filteredInventory}
                keyExtractor={(item) => item.item_id}
                contentContainerStyle={styles.listContent}
                renderItem={({ item }) => (
                  <View style={styles.itemRow}>
                    <TouchableOpacity
                      style={{ flex: 2 }}
                      onPress={() => openEditModal(item)}
                    >
                      <Text style={styles.itemName}>
                        {item.items?.name || "Unknown"}
                      </Text>
                      <Text style={styles.editHintText}>
                        ✏️ Tap to edit or delete
                      </Text>
                    </TouchableOpacity>
                    <View style={styles.actionsRight}>
                      <Text style={styles.itemStock}>
                        {item.quantity} {item.unit}
                      </Text>
                      <TouchableOpacity
                        style={styles.useButton}
                        onPress={() =>
                          handleUseItem(item.item_id, item.quantity)
                        }
                      >
                        <Text style={styles.buttonText}>USE</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                )}
              />
            </>
          )}
        </View>
      )}

      {/* 3. SHOPPING LIST MODULE */}
      {currentScreen === "shopping" && (
        <View style={{ flex: 1 }}>
          <Text style={styles.title}>Smart Shopping List</Text>
          <Text style={styles.subtitle}>Items flagged for purchase</Text>
          <FlatList
            data={shoppingItems}
            keyExtractor={(item) => item.item_id}
            contentContainerStyle={styles.listContent}
            renderItem={({ item }) => (
              <View
                style={[styles.itemRow, item.needed && styles.vitalRowBorder]}
              >
                <View style={{ flex: 1.5 }}>
                  <View style={{ flexDirection: "row", alignItems: "center" }}>
                    <Text style={styles.itemName}>
                      {item.items?.name || "Unknown"}
                    </Text>
                    {item.needed && (
                      <Text style={styles.vitalBadge}>! VITAL</Text>
                    )}
                  </View>
                  <Text style={styles.categoryLabel}>
                    Needed: {item.quantity_needed} {item.unit} (
                    {item.items?.category})
                  </Text>
                </View>
                <View style={styles.shoppingActions}>
                  <TouchableOpacity
                    style={[
                      styles.vitalButton,
                      item.needed && styles.vitalActiveButton,
                    ]}
                    onPress={() => handleToggleVital(item.item_id, item.needed)}
                  >
                    <Text
                      style={[
                        styles.buttonText,
                        item.needed && { color: "#fff" },
                      ]}
                    >
                      VITAL
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={styles.gotButton}
                    onPress={() => handleGotItem(item.item_id)}
                  >
                    <Text style={styles.buttonText}>GOT</Text>
                  </TouchableOpacity>
                </View>
              </View>
            )}
          />
        </View>
      )}

      {/* ADD MODAL PANEL */}
      <Modal visible={modalVisible} animationType="slide" transparent={true}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <Text style={styles.modalTitle}>Add New Pantry Item</Text>
            <Text style={styles.inputLabel}>Item Name</Text>
            <TextInput
              style={styles.inputField}
              placeholder="e.g. Chamomile"
              value={newItemName}
              onChangeText={setNewItemName}
            />
            <Text style={styles.inputLabel}>Folder Assignment</Text>
            <View style={styles.pickerAlternativeRow}>
              <FlatList
                horizontal
                showsHorizontalScrollIndicator={false}
                data={masterCategories}
                keyExtractor={(item) => item}
                renderItem={({ item }) => (
                  <TouchableOpacity
                    style={[
                      styles.categorySelectorChip,
                      newItemCategory === item && styles.activeChip,
                    ]}
                    onPress={() => setNewItemCategory(item)}
                  >
                    <Text
                      style={[
                        styles.chipText,
                        newItemCategory === item && { color: "#fff" },
                      ]}
                    >
                      {item}
                    </Text>
                  </TouchableOpacity>
                )}
              />
            </View>
            {/* REPLACE IT WITH THIS: */}
            <View style={{ flexDirection: "row", gap: 15, marginTop: 10 }}>
              <View style={{ flex: 1 }}>
                <Text style={styles.inputLabel}>Stock</Text>
                <TextInput
                  style={styles.inputField}
                  keyboardType="numeric"
                  value={newItemQty}
                  onChangeText={setNewItemQty}
                />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.inputLabel}>Unit</Text>
                <TextInput
                  style={styles.inputField}
                  value={newItemUnit}
                  onChangeText={setNewItemUnit}
                />
              </View>
            </View>
            <Text style={styles.inputLabel}>Low Stock Alert Threshold</Text>
            <TextInput
              style={styles.inputField}
              keyboardType="numeric"
              value={newItemMinQty}
              onChangeText={setNewItemMinQty}
            />
            <View style={styles.modalActionButtons}>
              <TouchableOpacity
                style={styles.cancelModalButton}
                onPress={() => setModalVisible(false)}
              >
                <Text style={[styles.buttonText, { color: "#666" }]}>
                  Cancel
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.saveModalButton}
                onPress={handleAddItem}
              >
                <Text style={styles.buttonText}>Save Item</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* EDIT / DELETE MODAL PANEL */}
      <Modal
        visible={editModalVisible}
        animationType="slide"
        transparent={true}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <View
              style={{
                flexDirection: "row",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <Text style={styles.modalTitle}>Modify / Edit Item</Text>
              <TouchableOpacity
                style={styles.deleteHeaderButton}
                onPress={handleDeleteItem}
              >
                <Text style={styles.deleteHeaderText}>🗑 DELETE</Text>
              </TouchableOpacity>
            </View>

            <Text style={styles.inputLabel}>Item Name</Text>
            <TextInput
              style={styles.inputField}
              value={editItemName}
              onChangeText={setEditItemName}
            />

            <Text style={styles.inputLabel}>Change Folder Assignment</Text>
            <View style={styles.pickerAlternativeRow}>
              <FlatList
                horizontal
                showsHorizontalScrollIndicator={false}
                data={masterCategories}
                keyExtractor={(item) => item}
                renderItem={({ item }) => (
                  <TouchableOpacity
                    style={[
                      styles.categorySelectorChip,
                      editItemCategory === item && styles.activeChip,
                    ]}
                    onPress={() => setEditItemCategory(item)}
                  >
                    <Text
                      style={[
                        styles.chipText,
                        editItemCategory === item && { color: "#fff" },
                      ]}
                    >
                      {item}
                    </Text>
                  </TouchableOpacity>
                )}
              />
            </View>

            <View style={{ flexDirection: "row", gap: 15, marginTop: 10 }}>
              <View style={{ flex: 1 }}>
                <Text style={styles.inputLabel}>Corrected Stock Count</Text>
                <TextInput
                  style={styles.inputField}
                  keyboardType="numeric"
                  value={editItemQty}
                  onChangeText={setEditItemQty}
                />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.inputLabel}>Unit</Text>
                <TextInput
                  style={styles.inputField}
                  value={editItemUnit}
                  onChangeText={setEditItemUnit}
                />
              </View>
            </View>

            <Text style={styles.inputLabel}>Low Stock Alert Threshold</Text>
            <TextInput
              style={styles.inputField}
              keyboardType="numeric"
              value={editItemMinQty}
              onChangeText={setEditItemMinQty}
            />

            <View style={styles.modalActionButtons}>
              <TouchableOpacity
                style={styles.cancelModalButton}
                onPress={() => {
                  setEditModalVisible(false);
                  setSelectedEditItem(null);
                }}
              >
                <Text style={[styles.buttonText, { color: "#666" }]}>
                  Cancel
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.saveModalButton}
                onPress={handleUpdateItem}
              >
                <Text style={styles.buttonText}>Save Changes</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fcfcfc",
    paddingHorizontal: 20,
    paddingTop: Platform.OS === "android" ? StatusBar.currentHeight + 10 : 20,
  },
  headerRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 5,
  },
  navTabs: {
    flexDirection: "row",
    marginBottom: 20,
    borderBottomWidth: 1,
    borderColor: "#e0e0e0",
  },
  tab: { flex: 1, paddingVertical: 12, alignItems: "center" },
  activeTab: { borderBottomWidth: 3, borderColor: "#4CAF50" },
  tabText: { fontSize: 16, color: "#888", fontWeight: "500" },
  activeTabText: { color: "#4CAF50", fontWeight: "700" },
  title: { fontSize: 26, fontWeight: "bold", color: "#2C3E50" },
  subtitle: { fontSize: 14, color: "#7F8C8D", marginBottom: 15 },

  addButton: {
    backgroundColor: "#4CAF50",
    paddingVertical: 6,
    paddingHorizontal: 14,
    borderRadius: 20,
  },
  addButtonText: { color: "#fff", fontWeight: "bold", fontSize: 13 },
  listContent: { paddingBottom: 120 },

  categoryCard: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 20,
    backgroundColor: "#fff",
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: "#eaeaea",
  },
  categoryCardText: { fontSize: 18, fontWeight: "600", color: "#2C3E50" },
  categoryCount: { fontSize: 14, color: "#95A5A6" },
  categoryHeader: { marginBottom: 15 },
  backButton: {
    alignSelf: "flex-start",
    paddingVertical: 6,
    paddingHorizontal: 12,
    backgroundColor: "#eaeaea",
    borderRadius: 6,
    marginBottom: 10,
  },
  backButtonText: { fontSize: 13, fontWeight: "600", color: "#555" },
  currentCategoryTitle: { fontSize: 20, fontWeight: "bold", color: "#34495E" },

  itemRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 15,
    backgroundColor: "#fff",
    borderRadius: 10,
    marginBottom: 10,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
  },
  itemName: { fontSize: 17, fontWeight: "600", color: "#333" },
  editHintText: {
    fontSize: 11,
    color: "#95A5A6",
    marginTop: 2,
    fontStyle: "italic",
  },
  categoryLabel: { fontSize: 12, color: "#95A5A6", marginTop: 2 },
  actionsRight: { flexDirection: "row", alignItems: "center", gap: 12 },
  itemStock: { fontSize: 15, fontWeight: "600", color: "#27AE60" },
  useButton: {
    backgroundColor: "#E67E22",
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 6,
  },
  shoppingActions: { flexDirection: "row", gap: 8 },
  vitalButton: {
    borderWidth: 1,
    borderColor: "#E74C3C",
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 6,
  },
  vitalActiveButton: { backgroundColor: "#E74C3C" },
  gotButton: {
    backgroundColor: "#2ECC71",
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 6,
  },
  buttonText: { fontSize: 12, fontWeight: "bold", color: "#fff" },
  vitalBadge: {
    backgroundColor: "#E74C3C",
    color: "#fff",
    fontSize: 10,
    fontWeight: "bold",
    paddingHorizontal: 5,
    paddingVertical: 2,
    borderRadius: 4,
    marginLeft: 8,
  },
  vitalRowBorder: { borderLeftWidth: 5, borderLeftColor: "#E74C3C" },

  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.4)",
    justifyContent: "flex-end",
  },
  modalContainer: {
    backgroundColor: "#fff",
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 24,
    maxHeight: "85%",
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#2C3E50",
    marginBottom: 5,
  },
  inputLabel: {
    fontSize: 13,
    fontWeight: "700",
    color: "#7F8C8D",
    marginBottom: 5,
    marginTop: 12,
  },
  inputField: {
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 8,
    padding: 10,
    fontSize: 15,
    backgroundColor: "#FAFAFA",
  },
  pickerAlternativeRow: { flexDirection: "row", paddingVertical: 5 },
  categorySelectorChip: {
    backgroundColor: "#EAEAEA",
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 20,
    marginRight: 8,
    height: 35,
  },
  activeChip: { backgroundColor: "#4CAF50" },
  chipText: { fontSize: 13, color: "#555", fontWeight: "600" },
  modalActionButtons: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 15,
    marginTop: 25,
    paddingBottom: 10,
  },
  cancelModalButton: {
    flex: 1,
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 8,
    paddingVertical: 12,
    alignItems: "center",
  },
  saveModalButton: {
    flex: 1,
    backgroundColor: "#4CAF50",
    borderRadius: 8,
    paddingVertical: 12,
    alignItems: "center",
  },

  deleteHeaderButton: {
    backgroundColor: "#FADBD8",
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 6,
  },
  deleteHeaderText: { color: "#C0392B", fontWeight: "bold", fontSize: 12 },
});
