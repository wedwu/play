import { useEffect, useState } from "react";
import { Alert } from "react-native";
import * as inventoryApi from "../api/inventoryApi";
import * as shoppingApi from "../api/shoppingApi";
import { masterCategories } from "../const";

// Owns all inventory + shopping-list state and the actions that mutate it.
// Components below this hook stay purely presentational.
export const usePantry = () => {
  const [currentScreen, setCurrentScreen] = useState("inventory"); // 'inventory' | 'shopping'
  const [inventoryItems, setInventoryItems] = useState([]);
  const [shoppingItems, setShoppingItems] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(null);

  const loadInventory = async () => {
    try {
      setInventoryItems(await inventoryApi.fetchInventory());
    } catch (error) {
      console.error("Error fetching inventory:", error.message);
    }
  };

  const loadShoppingList = async () => {
    try {
      setShoppingItems(await shoppingApi.fetchShoppingList());
    } catch (error) {
      console.error("Error fetching shopping list:", error.message);
    }
  };

  const refresh = async () => {
    if (currentScreen === "inventory") await loadInventory();
    else await loadShoppingList();
  };

  useEffect(() => {
    refresh();
  }, [currentScreen]);

  // --- Inventory actions (return true on success so modals can close). ---

  const addItem = async (form) => {
    if (!form.name.trim()) {
      Alert.alert("Missing Name", "Please type an item name before saving.");
    }
    try {
      const unit = form.unit.trim() || "pcs";
      await inventoryApi.createItem({
        name: form.name.trim(),
        category: form.category,
        unit,
        quantity: parseInt(form.quantity, 10) || 0,
        minQuantity: parseInt(form.minQuantity, 10) || 0,
      });

      setSelectedCategory(form.category); // jump straight into the new folder
      await refresh();
      return true;
    } catch (error) {
      Alert.alert("Database Error", error.message);
      return false;
    }
  };

  const updateItem = async (item, form) => {
    if (!form.name.trim()) {
      Alert.alert("Missing Name", "Item name cannot be blank.");
    }
    try {
      await inventoryApi.updateItem({
        itemId: item.items.id,
        inventoryItemId: item.item_id,
        name: form.name.trim(),
        category: form.category,
        quantity: parseInt(form.quantity, 10) || 0,
        unit: form.unit.trim() || "pcs",
        minQuantity: parseInt(form.minQuantity, 10) || 0,
      });

      // If the category changed, drop back to the folder list.
      if (form.category !== selectedCategory) setSelectedCategory(null);

      await refresh();
      Alert.alert("Success", "Item updated beautifully.");
      return true;
    } catch (error) {
      Alert.alert("Update Error", error.message);
      return false;
    }
  };

  const deleteItem = async (item) => {
    try {
      await inventoryApi.deleteItem({
        itemId: item.items.id,
        inventoryItemId: item.item_id,
      });
      await refresh();
      Alert.alert("Deleted", "Item completely cleared from your system.");
      return true;
    } catch (error) {
      Alert.alert("Deletion Error", error.message);
      return false;
    }
  };

  // Deduct one unit; auto-add to the shopping list when at/below the threshold.
  const useItem = async (itemId, currentQty) => {
    if (currentQty <= 0) {
      Alert.alert("Out of stock!", "This item is already at 0.");
    }
    const newQty = currentQty - 1;
    try {
      await inventoryApi.setInventoryQuantity(itemId, newQty);

      setInventoryItems((prev) =>
        prev.map((item) =>
          item.item_id === itemId ? { ...item, quantity: newQty } : item,
        ),
      );

      const modifiedItem = inventoryItems.find(
        (item) => item.item_id === itemId,
      );
      const minQty = modifiedItem?.min_quantity || 0;

      if (newQty <= minQty) {
        const exactQuantityNeeded = minQty - newQty;
        // At the minimum exactly (but not below) we still need at least 1.
        const finalNeeded = exactQuantityNeeded === 0 ? 1 : exactQuantityNeeded;

        const existingShopItem = await shoppingApi.findShoppingItem(itemId);

        if (!existingShopItem) {
          await shoppingApi.addShoppingItem({
            itemId,
            quantityNeeded: finalNeeded,
            unit: modifiedItem?.unit || "pcs",
          });
          Alert.alert(
            "Low Stock Alert!",
            `"${modifiedItem?.items?.name}" dropped to ${newQty}. Need ${finalNeeded} more to hit your minimum.`,
          );
        } else {
          await shoppingApi.setQuantityNeeded(itemId, finalNeeded);
        }
      }
    } catch (error) {
      Alert.alert("Automation Error", error.message);
    }
  };

  // --- Shopping actions. ---

  const toggleVital = async (itemId, currentNeededStatus) => {
    try {
      await shoppingApi.setNeeded(itemId, !currentNeededStatus);
      setShoppingItems((prev) =>
        prev.map((item) =>
          item.item_id === itemId
            ? { ...item, needed: !currentNeededStatus }
            : item,
        ),
      );
    } catch (error) {
      console.error(error.message);
    }
  };

  // Buy the item: top up inventory, then remove it from the shopping list.
  const gotItem = async (itemId) => {
    try {
      const shopItem = shoppingItems.find((item) => item.item_id === itemId);
      if (!shopItem) {
        Alert.alert(
          "Restock Error",
          "This item is no longer on the shopping list.",
        );
        return;
      }
      const amountBought = shopItem.quantity_needed || 1;

      const currentQty = await inventoryApi.getInventoryQuantity(itemId);
      await inventoryApi.setInventoryQuantity(itemId, currentQty + amountBought);
      await shoppingApi.removeShoppingItem(itemId);

      await refresh();
      Alert.alert(
        "Restocked!",
        `Added ${amountBought} back to your pantry inventory.`,
      );
    } catch (error) {
      Alert.alert("Restock Error", error.message);
    }
  };

  // --- Derived view data. ---
  const categoryFolders = masterCategories.filter((category) =>
    inventoryItems.some((item) => item.items?.category === category),
  );
  const filteredInventory = inventoryItems.filter(
    (item) => item.items?.category === selectedCategory,
  );

  return {
    currentScreen,
    setCurrentScreen,
    inventoryItems,
    shoppingItems,
    selectedCategory,
    setSelectedCategory,
    categoryFolders,
    filteredInventory,
    addItem,
    updateItem,
    deleteItem,
    useItem,
    toggleVital,
    gotItem,
  };
};
