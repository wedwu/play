import { useEffect, useState } from "react";
import { Alert } from "react-native";
import * as SplashScreen from "expo-splash-screen";
import {
  getActiveSession,
  getProfile,
  onAuthStateChange,
  signInWithPassword,
} from "../api/authApi";

// Owns session/profile state, the native splash lifecycle, and login.
export const useAuth = () => {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [appReady, setAppReady] = useState(false); // gates the branded splash image

  useEffect(() => {
    // Restore any session already active on this device.
    getActiveSession().then(async (activeSession) => {
      setSession(activeSession);
      if (activeSession) {
        const profData = await getProfile(activeSession.user.id);
        if (profData) setProfile(profData);
      }
      SplashScreen.hideAsync();
    });

    // React to manual logins / logouts.
    const { data: authListener } = onAuthStateChange((_event, currentSession) => {
      setSession(currentSession);
      if (!currentSession) setProfile(null);
    });

    // Forced preview timer to hold the splash image on screen.
    const timer = setTimeout(() => setAppReady(true), 2500);

    return () => {
      clearTimeout(timer);
      authListener.subscription.unsubscribe();
    };
  }, []);

  const login = async (email, password) => {
    if (!email || !password) {
      return Alert.alert(
        "Missing Fields",
        "Please enter both email and password.",
      );
    }
    const { error } = await signInWithPassword(email, password);
    if (error) Alert.alert("Login Error", error.message);
  };

  return { session, profile, appReady, login };
};
