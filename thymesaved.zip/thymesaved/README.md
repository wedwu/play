# 🌿 ThymeSaved Pantry

A React Native (Expo) app for tracking a shared household pantry. Browse stock
by category, deduct items as you use them, and let the app automatically build a
smart shopping list when anything drops below its low-stock threshold.

## Features

- **Email/password auth** via Supabase, with persisted sessions.
- **Pantry inventory** organized into category folders, with add / edit / delete.
- **One-tap "USE"** to deduct a unit of stock.
- **Smart low-stock automation** — using an item down to (or below) its minimum
  auto-adds it to the shopping list with the exact quantity needed.
- **Shopping list** with a "VITAL" flag and a "GOT" action that restocks the
  pantry and clears the item.

## Tech stack

- [Expo](https://docs.expo.dev/versions/v56.0.0/) SDK 56 / React Native 0.85
- React 19
- [Supabase](https://supabase.com/) (auth + Postgres) via `@supabase/supabase-js`
- `@react-native-async-storage/async-storage` for session persistence

## Getting started

### Prerequisites

- Node.js (LTS)
- The [Expo Go](https://expo.dev/go) app, or an iOS/Android simulator
- A Supabase project

### 1. Install dependencies

```bash
npm install
```

### 2. Configure environment variables

Create a `.env` file in the project root (it is git-ignored):

```bash
EXPO_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
```

> These use Expo's `EXPO_PUBLIC_` prefix so they are inlined into the client
> bundle. The anon key is **meant** to be public — your actual security boundary
> is Supabase Row Level Security (see [Security](#security) below).

### 3. Run the app

```bash
npm start          # Expo dev server (scan the QR code with Expo Go)
npm run ios        # build & run on iOS
npm run android    # build & run on Android
npm run web        # run in the browser
```

## Database schema

The app expects these Supabase tables:

| Table           | Key columns                                                        |
| --------------- | ------------------------------------------------------------------ |
| `profiles`      | `id` (FK → auth user)                                               |
| `items`         | `id`, `name`, `category`, `default_unit`                           |
| `inventory`     | `item_id` (FK → items), `quantity`, `unit`, `min_quantity`        |
| `shopping_list` | `item_id` (FK → items), `quantity_needed`, `unit`, `needed`, `purchased` |

## Project structure

The codebase is split into three layers so that `App.js` stays a thin shell and
no single file mixes data access, business logic, and rendering.

```
App.js                  Thin shell: routes between splash / login / app by auth state
supabase.js             Supabase client (reads EXPO_PUBLIC_* env vars)
const/                  Static data (master category list)

api/                    Data layer — pure Supabase calls, no React
  authApi.js              session, profile, sign-in
  inventoryApi.js         items + inventory CRUD
  shoppingApi.js          shopping_list CRUD

hooks/                  Logic layer — state + orchestration
  useAuth.js              session/profile/splash lifecycle + login
  usePantry.js            inventory/shopping state + all actions + derived data

screens/                Presentation — full-screen views
  SplashImage.js          branded hold screen
  LoginScreen.js          email/password gate
  PantryApp.js            authenticated container (tabs + modals)
  InventoryScreen.js      category folders / item list
  ShoppingScreen.js       smart shopping list

components/              Presentation — reusable pieces
  NavTabs.js
  CategoryChips.js        horizontal single-select category picker
  AddItemModal.js
  EditItemModal.js

theme/
  styles.js               shared StyleSheet
```

**Data flow:** `screens`/`components` are purely presentational — they receive
data and callbacks as props. Those callbacks come from the `hooks` layer, which
holds all state and calls into the `api` layer. The `api` layer is the only code
that talks to Supabase.

## Security

The Supabase **anon key ships in the client bundle** and the login screen is a
UI gate only — it does not enforce access at the API level. All real security
depends on **Row Level Security (RLS) policies** configured in your Supabase
dashboard.

Verify RLS is enabled before shipping. With no auth token, this should return an
error or an empty array — never your data:

```bash
curl "$EXPO_PUBLIC_SUPABASE_URL/rest/v1/inventory?select=*" \
  -H "apikey: $EXPO_PUBLIC_SUPABASE_ANON_KEY"
```

Note: the app currently treats inventory as a single **shared household**
dataset — queries are not scoped per user. If you need per-user/per-household
isolation, add an owner column and matching RLS policies keyed to `auth.uid()`.

## License

See [LICENSE](LICENSE).
