import React, { useState } from "react";
import {
  Modal,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { masterCategories } from "../const";
import { styles } from "../theme/styles";
import CategoryChips from "./CategoryChips";

const DEFAULTS = {
  name: "",
  category: masterCategories[12], // "Herbs"
  quantity: "1",
  unit: "packets",
  minQuantity: "1",
};

// Self-contained "add" form. Owns its own input state; reports values up
// through onSubmit, which resolves truthy on success so we can close + reset.
export default function AddItemModal({ visible, onClose, onSubmit }) {
  const [name, setName] = useState(DEFAULTS.name);
  const [category, setCategory] = useState(DEFAULTS.category);
  const [quantity, setQuantity] = useState(DEFAULTS.quantity);
  const [unit, setUnit] = useState(DEFAULTS.unit);
  const [minQuantity, setMinQuantity] = useState(DEFAULTS.minQuantity);

  const handleSave = async () => {
    const ok = await onSubmit({ name, category, quantity, unit, minQuantity });
    if (ok) {
      // Match the original reset: clears name/qty/min, keeps unit + category.
      setName(DEFAULTS.name);
      setQuantity(DEFAULTS.quantity);
      setMinQuantity(DEFAULTS.minQuantity);
      onClose();
    }
  };

  return (
    <Modal visible={visible} animationType="slide" transparent={true}>
      <View style={styles.modalOverlay}>
        <View style={styles.modalContainer}>
          <Text style={styles.modalTitle}>Add New Pantry Item</Text>

          <Text style={styles.inputLabel}>Item Name</Text>
          <TextInput
            style={styles.inputField}
            placeholder="e.g. Chamomile"
            value={name}
            onChangeText={setName}
          />

          <Text style={styles.inputLabel}>Folder Assignment</Text>
          <CategoryChips
            categories={masterCategories}
            selected={category}
            onSelect={setCategory}
          />

          <View style={{ flexDirection: "row", gap: 15, marginTop: 10 }}>
            <View style={{ flex: 1 }}>
              <Text style={styles.inputLabel}>Stock</Text>
              <TextInput
                style={styles.inputField}
                keyboardType="numeric"
                value={quantity}
                onChangeText={setQuantity}
              />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.inputLabel}>Unit</Text>
              <TextInput
                style={styles.inputField}
                value={unit}
                onChangeText={setUnit}
              />
            </View>
          </View>

          <Text style={styles.inputLabel}>Low Stock Alert Threshold</Text>
          <TextInput
            style={styles.inputField}
            keyboardType="numeric"
            value={minQuantity}
            onChangeText={setMinQuantity}
          />

          <View style={styles.modalActionButtons}>
            <TouchableOpacity style={styles.cancelModalButton} onPress={onClose}>
              <Text style={[styles.buttonText, { color: "#666" }]}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.saveModalButton} onPress={handleSave}>
              <Text style={styles.buttonText}>Save Item</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}
