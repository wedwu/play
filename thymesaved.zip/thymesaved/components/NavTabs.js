import React from "react";
import { Text, TouchableOpacity, View } from "react-native";
import { styles } from "../theme/styles";

const TABS = [
  { key: "inventory", label: "Pantry Inventory" },
  { key: "shopping", label: "Shopping List" },
];

export default function NavTabs({ current, onChange }) {
  return (
    <View style={styles.navTabs}>
      {TABS.map((tab) => {
        const active = current === tab.key;
        return (
          <TouchableOpacity
            key={tab.key}
            style={[styles.tab, active && styles.activeTab]}
            onPress={() => onChange(tab.key)}
          >
            <Text style={[styles.tabText, active && styles.activeTabText]}>
              {tab.label}
            </Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}
