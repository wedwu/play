import React, { useEffect, useState } from "react";
import {
  Alert,
  Modal,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { masterCategories } from "../const";
import { styles } from "../theme/styles";
import CategoryChips from "./CategoryChips";

// Edit/delete form. Visible whenever `item` is set; seeds its local state from
// that item. onSave/onDelete resolve truthy on success so we can close.
export default function EditItemModal({ item, onClose, onSave, onDelete }) {
  const [name, setName] = useState("");
  const [category, setCategory] = useState("Herbs");
  const [quantity, setQuantity] = useState("");
  const [unit, setUnit] = useState("");
  const [minQuantity, setMinQuantity] = useState("");

  useEffect(() => {
    if (!item) return;
    setName(item.items?.name || "");
    setCategory(item.items?.category || "Herbs");
    setQuantity(String(item.quantity || 0));
    setUnit(item.unit || "pcs");
    setMinQuantity(String(item.min_quantity || 0));
  }, [item]);

  const handleSave = async () => {
    const ok = await onSave(item, { name, category, quantity, unit, minQuantity });
    if (ok) onClose();
  };

  const handleDelete = () => {
    Alert.alert(
      "Confirm Deletion",
      `Are you absolutely sure you want to remove "${name}" from your pantry entirely?`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: async () => {
            const ok = await onDelete(item);
            if (ok) onClose();
          },
        },
      ],
    );
  };

  return (
    <Modal visible={!!item} animationType="slide" transparent={true}>
      <View style={styles.modalOverlay}>
        <View style={styles.modalContainer}>
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <Text style={styles.modalTitle}>Modify / Edit Item</Text>
            <TouchableOpacity
              style={styles.deleteHeaderButton}
              onPress={handleDelete}
            >
              <Text style={styles.deleteHeaderText}>🗑 DELETE</Text>
            </TouchableOpacity>
          </View>

          <Text style={styles.inputLabel}>Item Name</Text>
          <TextInput
            style={styles.inputField}
            value={name}
            onChangeText={setName}
          />

          <Text style={styles.inputLabel}>Change Folder Assignment</Text>
          <CategoryChips
            categories={masterCategories}
            selected={category}
            onSelect={setCategory}
          />

          <View style={{ flexDirection: "row", gap: 15, marginTop: 10 }}>
            <View style={{ flex: 1 }}>
              <Text style={styles.inputLabel}>Corrected Stock Count</Text>
              <TextInput
                style={styles.inputField}
                keyboardType="numeric"
                value={quantity}
                onChangeText={setQuantity}
              />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.inputLabel}>Unit</Text>
              <TextInput
                style={styles.inputField}
                value={unit}
                onChangeText={setUnit}
              />
            </View>
          </View>

          <Text style={styles.inputLabel}>Low Stock Alert Threshold</Text>
          <TextInput
            style={styles.inputField}
            keyboardType="numeric"
            value={minQuantity}
            onChangeText={setMinQuantity}
          />

          <View style={styles.modalActionButtons}>
            <TouchableOpacity style={styles.cancelModalButton} onPress={onClose}>
              <Text style={[styles.buttonText, { color: "#666" }]}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.saveModalButton} onPress={handleSave}>
              <Text style={styles.buttonText}>Save Changes</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}
