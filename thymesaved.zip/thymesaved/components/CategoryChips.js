import React from "react";
import { FlatList, Text, TouchableOpacity, View } from "react-native";
import { styles } from "../theme/styles";

// Horizontal, single-select chip picker used by both add & edit modals.
export default function CategoryChips({ categories, selected, onSelect }) {
  return (
    <View style={styles.pickerAlternativeRow}>
      <FlatList
        horizontal
        showsHorizontalScrollIndicator={false}
        data={categories}
        keyExtractor={(item) => item}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={[
              styles.categorySelectorChip,
              selected === item && styles.activeChip,
            ]}
            onPress={() => onSelect(item)}
          >
            <Text
              style={[styles.chipText, selected === item && { color: "#fff" }]}
            >
              {item}
            </Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}
